﻿=== Bloody Pointers Pack Cursor Set ===

By: Harksmau (http://www.rw-designer.com/user/43995)

Download: http://www.rw-designer.com/cursor-set/bloodycursorpack

Author's description:

This is the bloody pack... You must be bitten by a zombie... wolf or werewolf to become bleeding.. and that is all!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.