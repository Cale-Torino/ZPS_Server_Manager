﻿APPLICATION CREATED BY CA TORINO 2022

-------------------------------------
## Version: 1.0.0
## Date: 06-19-2022
## Author: C.A Torino
-------------------------------------

Added transparent blur class
Added easter egg
Added mp3 capability
Added bass.dll
Added Darkmode title bar
Added dark mode explorer controls
Added Logs
Added custom cursor and animated cursor


-------------------------------------
## MUSIC
-------------------------------------

Music: Bungholio feat. Cornholio (Original Mix) by Espiritual Gambler
Source: https://soundcloud.com/espiritual-gambler/bungholio
License: http://creativecommons.org/licenses/by/3.0/
Get music free for a link from https://starfrosch.com
https://starfrosch.com/hot-111/royalty-free-music/cornholio

-------------------------------------
## UPDATER
-------------------------------------
See license folder

https://www.codeproject.com/Tips/5246721/Update-Checker


